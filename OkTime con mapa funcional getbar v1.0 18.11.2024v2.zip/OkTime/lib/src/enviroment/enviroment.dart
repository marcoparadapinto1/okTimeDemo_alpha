class Enviroment {
  static const String API_URL = "http://192.168.100.77:3000/";
  static const String API_KEY_MAPS = "AIzaSyBk5pMKBVNijrKQK2TVBzM00ObLDFIl6X0";

}